public function test${CAPITALIZED_NAME}() {

}