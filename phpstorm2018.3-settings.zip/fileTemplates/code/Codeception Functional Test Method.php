public function test${CAPITALIZED_NAME}(FunctionalTester $I) {

}