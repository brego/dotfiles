public function __construct(${PARAM_LIST}) {
    ${BODY}
}